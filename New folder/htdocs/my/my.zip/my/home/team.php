<!-- Section Start - Meet Our Team -->
<section class=' padding-bottom-0 ' id='team'>
		<!-- Angled Section - Start -->
		<div class="angled_down_inside white">
			<div class="slope upleft"></div>
			<div class="slope upright"></div>
		</div>
		<!-- Angled Section - End -->
		
	<div class="container">
	<div class="row">
			<h1 class="heading">Meet Our Team</h1>
			<div class="headul"></div>
			<p class="subheading">Lorem ipsum dolor sit amet, consectetuer adipiscing elit enean commodo  eget dolor aenean massa eget dolor aenean massa</p>
			
		<!-- Team Member - Start -->
		<div class="col-lg-4 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1 member inviewport animated delay1" data-effect="fadeInUp">
			<div class="pic">
				<img alt="member-image" class="img-responsive" src="img/member-1.jpg">	
				<div class="social">
					<a href="#"><i class="mdi mdi-dribbble text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-twitter text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-facebook text-on-primary"></i></a>
				</div>
			</div>
			<div class="info">
				<h3>John Arthur</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Team Member - End -->

			
		<!-- Team Member - Start -->
		<div class="col-lg-4 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1 member inviewport animated delay2" data-effect="fadeInUp">
			<div class="pic">
				<img alt="member-image" class="img-responsive" src="img/member-2.jpg">	
				<div class="social">
					<a href="#"><i class="mdi mdi-dribbble text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-twitter text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-facebook text-on-primary"></i></a>
				</div>
			</div>
			<div class="info">
				<h3>Kate Douglas</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Team Member - End -->

			
		<!-- Team Member - Start -->
		<div class="col-lg-4 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2 col-xs-10 col-xs-offset-1 member inviewport animated delay3" data-effect="fadeInUp">
			<div class="pic">
				<img alt="member-image" class="img-responsive" src="img/member-3.jpg">	
				<div class="social">
					<a href="#"><i class="mdi mdi-dribbble text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-twitter text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-facebook text-on-primary"></i></a>
				</div>
			</div>
			<div class="info">
				<h3>Jimmy Patrick</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Team Member - End -->

	   </div>

	</div>
		<!-- Angled Section - Start -->
		<div class="angled_up_inside white">
			<div class="slope upleft"></div>
			<div class="slope upright"></div>
		</div>
		<!-- Angled Section - End -->
		
	</section>
<!-- Section End - Meet Our Team -->