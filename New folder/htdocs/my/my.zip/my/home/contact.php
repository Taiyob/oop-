<!-- Section Start - Contact Us -->

	<section class="parallax contact padding-top-150 " id="contact">
	<div class="bg-overlay opacity-85"></div>
	<div class="container">
	<div class="">
					<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 inviewport animated delay1" data-effect="fadeInUp">
				
<!-- Contact Form - Start -->
<form action='http://jaybabani.com/caliber-html/send_email.php' method='post'><input type='text' placeholder='Name' class='col-xs-12 transition' id='c_name' ><input type='text' placeholder='Email' class='col-xs-12 transition' id='c_email' ><input type='text' placeholder='Phone' class='col-xs-12 transition' id='c_phone' ><textarea class='col-xs-12 transition' placeholder='Message' id='c_message' ></textarea><div id='response_email'></div><button type='button' class='btn btn-block btn-primary disabled transition' id='c_send'>Send Message</button></form>
<!-- Contact Form - End -->
			</div>

			<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 contacts inviewport animated delay1" data-effect="fadeInUp">
				
<!-- Contact Person - Start -->
<div class='contact-person'>
	<div class='col-sm-6 col-sm-4 col-xs-4 pic'>
		<img alt='contact-person' src='img/contact-1.jpg' class='img-responsive'>
	</div>
	<div class='col-md-6 col-sm-8 col-xs-8 info'>
	<h4>John Doe</h4>
	<div class='post'>President</div>
	<div>Email: email@ex.com</div>
	<div>Phone: +1 234 434 4333</div>
	<div class='hidden-md hidden-xs'>Fax: +1 234 434 4333</div>

				<div class="social">
					<a href="#"><i class="mdi mdi-facebook text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-twitter text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-dribbble text-on-primary"></i></a>
				</div>

</div></div>
<!-- Contact Person - End -->
				
<!-- Contact Person - Start -->
<div class='contact-person'>
	<div class='col-sm-6 col-sm-4 col-xs-4 pic'>
		<img alt='contact-person' src='img/contact-2.jpg' class='img-responsive'>
	</div>
	<div class='col-md-6 col-sm-8 col-xs-8 info'>
	<h4>Sam Arthur</h4>
	<div class='post'>CEO</div>
	<div>Email: email@ex.com</div>
	<div>Phone: +1 234 434 4333</div>
	<div class='hidden-md hidden-xs'>Fax: +1 234 434 4333</div>

				<div class="social">
					<a href="#"><i class="mdi mdi-facebook text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-twitter text-on-primary"></i></a>
					<a href="#"><i class="mdi mdi-dribbble text-on-primary"></i></a>
				</div>

</div></div>
<!-- Contact Person - End -->
			</div>

	   </div>
	</div>
	</section>


<!-- Section End - Contact Us -->