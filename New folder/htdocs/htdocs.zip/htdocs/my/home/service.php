	<h1 class="heading">Why Choose Us</h1>
			<div class="headul"></div>
			<p class="subheading">Lorem ipsum dolor sit amet, consectetuer adipiscing elit enean commodo  eget dolor aenean massa eget dolor aenean massa</p>
			<div class="features">
				

		<!-- Feature - Start -->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 feature inviewport animated delay1" data-effect="fadeInUp">
			<div class="icon">	
				<i class="mdi mdi-desktop-mac"></i>
			</div>
			<div class="info">
				<h3 class="title">Web Design</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Feature - End -->

				

		<!-- Feature - Start -->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 feature inviewport animated delay2" data-effect="fadeInUp">
			<div class="icon">	
				<i class="mdi mdi-server-network"></i>
			</div>
			<div class="info">
				<h3 class="title">Hosting</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Feature - End -->

				

		<!-- Feature - Start -->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 feature inviewport animated delay3" data-effect="fadeInUp">
			<div class="icon">	
				<i class="mdi mdi-format-paint"></i>
			</div>
			<div class="info">
				<h3 class="title">Photoshop</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Feature - End -->

				

		<!-- Feature - Start -->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 feature inviewport animated delay1" data-effect="fadeInUp">
			<div class="icon">	
				<i class="mdi mdi-camera"></i>
			</div>
			<div class="info">
				<h3 class="title">Photography</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Feature - End -->

				

		<!-- Feature - Start -->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 feature inviewport animated delay2" data-effect="fadeInUp">
			<div class="icon">	
				<i class="mdi mdi-chart-areaspline"></i>
			</div>
			<div class="info">
				<h3 class="title">Development</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Feature - End -->

				

		<!-- Feature - Start -->
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 feature inviewport animated delay3" data-effect="fadeInUp">
			<div class="icon">	
				<i class="mdi mdi-vector-curve"></i>
			</div>
			<div class="info">
				<h3 class="title">Illustrator</h3>
				<p>We at Caliber design and create brilliance at work in a uniquely stylish process.</p>				
			</div>
		</div>
		<!-- Feature - End -->

			</div>
	   </div>

	</div>
		<!-- Angled Section - Start -->
		<div class="angled_up_inside white">
			<div class="slope upleft"></div>
			<div class="slope upright"></div>
		</div>
		<!-- Angled Section - End -->
		
	</section>
<!-- Section End - Why Choose Us -->

<!-- Section Start - Services -->
<section class='bg-primary services max-width-100 padding-bottom-0 ' id='services'><div class="container">	<div class="row">
		<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
			<h1 class="heading text-white left-align">Services</h1>
			<div class="headul white left-align"></div>
			<p class="subheading text-white left-align">Features & Specifications</p>
			<p>Nam quam nunc, blandit vel, luctus pulvinar, hend lorem. Maecenas nec odioet ante tincidunt tempus luctus pulvinar, hendrerit id, lorem.</p>
			<p>Maecenas nec odio et ante tincidunt tempus natoque penatibuset magnis dis parturient nascetur ridiculus mus.</p>
		</div>
		<div class="col-lg-9 col-md-10 col-md-offset-1 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0 service-tablets">
			<div class="tablet-black inviewport animated delay1" data-effect="fadeInRight"><img alt="tablet-black" src="img/tablet-black-yellow.png" class="style-dependent img-responsive"></div>
			<div class="tablet-white inviewport animated delay2" data-effect="fadeInRight"><img alt="tablet-white" src="img/tablet-white-yellow.png" class="style-dependent img-responsive"></div>
		</div>
	   </div>

</div>
		<!-- Angled Section - Start -->
		<div class="angled_down_outside outside primary white">
			<div class="slope downleft"></div>
			<div class="slope downright"></div>
		</div>		
		<!-- Angled Section - End -->

	</section>
<!-- Section End - Services -->