<!-- Section Start - Blog Single Page -->
<section class=' padding-top-100 padding-bottom-0 '>
		<!-- Angled Section - Start -->
		<div class="angled_down_inside white">
			<div class="slope upleft"></div>
			<div class="slope upright"></div>
		</div>
		<!-- Angled Section - End -->
		
	<div class="container">

	<div class="row">
			<h1 class="heading">Blog Single Page</h1>
			<div class="headul"></div>
			<p class="subheading">Lorem ipsum dolor sit amet, consectetuer adipiscing elit enean commodo  eget dolor aenean massa eget dolor aenean massa</p>


				<div class="blog blog-full">
					<div class="col-lg-10 col-md-12 col-sm-12 col-xs-12 info inviewport animated delay1" data-effect="fadeIn">
						<span class="date">24th August 2015</span>
						<h3 class="title"><a href="blog-single.html">TEN AMAZING AND STRANGE PICTURES BY PROFESSIONALS</a></h3>
						<p class="meta"><span>10 Comments</span> <span>In: <a href='#'>Web Design</a>, <a href='#'>Photography</a>, <a href='#'>General</a></span> <span>Post By: <a href='#'>Admin</a></span></p>
						<p>Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu. In  justo, rhoncus ut, imperdiet a, venenatis vitaerdiet erde justo. llam dictum felis eu pede mollis pretium diet a, venenatis vita sto. Nullam dictum felis eu pede mollis pretiumdiet a, venenatis ie ust. ullam dictum felis eu pedemol iumpretium ieta.</p>
					</div>

					<div class="col-lg-10 col-md-12 col-sm-12 col-xs-12 media inviewport animated delay1" data-effect="fadeIn">
						<img alt="blog-image" class="img-responsive" src="img/blog-large-1.jpg">
					</div>

					<div class="clearfix"></div>

					<div class="col-lg-10 col-md-12 col-sm-12 col-xs-12 info inviewport animated delay1" data-effect="fadeIn">
						<p>Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu. In  justo, rhoncus ut, imperdiet a, venenatis vitaerdiet erde justo. llam dictum felis eu pede mollis pretium diet a, venenatis vita sto. Nullam dictum felis eu pede mollis pretiumdiet a, venenatis ie ust. ullam dictum felis eu pedemol iumpretium ieta. Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu. In  justo, rhoncus ut, imperdiet a, venenatis vitaerdiet erde justo. llam dictum felis eu pede mollis pretium diet a, venenatis vita sto. Nullam dictum felis eu pede mollis pretiumdiet a, venenatis ie ust. ullam dictum felis eu pedemol iumpretium ieta. Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu. In  justo, rhoncus ut, imperdiet a, venenatis vitaerdiet erde justo. llam dictum felis eu pede mollis pretium diet a, venenatis vita sto. Nullam dictum felis eu pede mollis pretiumdiet a, venenatis ie ust. ullam dictum felis eu pedemol iumpretium ieta.</p>
						<p>Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu. In  justo, rhoncus ut, imperdiet a, venenatis vitaerdiet erde justo. llam dictum felis eu pede mollis pretium diet a, venenatis vita sto. Nullam dictum felis eu pede mollis pretiumdiet a, venenatis ie ust. ullam dictum felis eu pedemol iumpretium ieta. Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu. In  justo, rhoncus ut, imperdiet a, venenatis vitaerdiet erde justo. llam dictum felis eu pede mollis pretium diet a, venenatis vita sto. Nullam dictum felis eu pede mollis pretiumdiet a, venenatis ie ust. ullam dictum felis eu pedemol iumpretium ieta. Donec pede justo, fringilla, aliquet nec, vulputatee egerdiet erdiett arcu.</p>
					</div>

					<div class="clearfix"></div>
				
					<!-- Comments Section - Start -->
					<div class="col-lg-10 col-md-12 col-sm-12 col-xs-12 comments inviewport animated delay1" data-effect="fadeIn">

					<h4>Comments</h4>
					
                    <!-- Comment - Start -->
			<div class="well comment-block level-1" style="display:inline-block;">
                        <div class="col-md-1 col-sm-2 col-xs-3 img-area">
                            <img src="img/avatar-1.jpg" class=" img-responsive">
                        </div>
                        <div class="col-md-11 col-sm-10 col-xs-9">
                            <h5>By <a href="#">Jason</a> on May 12, 2015.</h5>
                            <div>
                                <p>Bacon ipsum dolor sit amet nulla ham qui sint exercitation eiusmod commodo, chuck duis velit. Aute in reprehenderit, dolore aliqua non est magna in labore pig pork biltong in labore pig pork biltong.</p>
                            </div>
                            <a href="#" class="pull-left">Reply &raquo;</a>
                        </div>
                    </div>
                    <!-- Comment - End -->

					
                    <!-- Comment - Start -->
			<div class="well comment-block level-2" style="display:inline-block;">
                        <div class="col-md-1 col-sm-2 col-xs-3 img-area">
                            <img src="img/avatar-2.jpg" class=" img-responsive">
                        </div>
                        <div class="col-md-11 col-sm-10 col-xs-9">
                            <h5>By <a href="#">Jason</a> on May 12, 2015.</h5>
                            <div>
                                <p>Bacon ipsum dolor sit amet nulla ham qui sint exercitation eiusmod commodo, chuck duis velit. Aute in reprehenderit, dolore aliqua non est magna in labore pig pork biltong in labore pig pork biltong.</p>
                            </div>
                            <a href="#" class="pull-left">Reply &raquo;</a>
                        </div>
                    </div>
                    <!-- Comment - End -->

					
                    <!-- Comment - Start -->
			<div class="well comment-block level-3" style="display:inline-block;">
                        <div class="col-md-1 col-sm-2 col-xs-3 img-area">
                            <img src="img/avatar-3.jpg" class=" img-responsive">
                        </div>
                        <div class="col-md-11 col-sm-10 col-xs-9">
                            <h5>By <a href="#">Jason</a> on May 12, 2015.</h5>
                            <div>
                                <p>Bacon ipsum dolor sit amet nulla ham qui sint exercitation eiusmod commodo, chuck duis velit. Aute in reprehenderit, dolore aliqua non est magna in labore pig pork biltong in labore pig pork biltong.</p>
                            </div>
                            <a href="#" class="pull-left">Reply &raquo;</a>
                        </div>
                    </div>
                    <!-- Comment - End -->

					
                    <!-- Comment - Start -->
			<div class="well comment-block level-1" style="display:inline-block;">
                        <div class="col-md-1 col-sm-2 col-xs-3 img-area">
                            <img src="img/avatar-4.jpg" class=" img-responsive">
                        </div>
                        <div class="col-md-11 col-sm-10 col-xs-9">
                            <h5>By <a href="#">Jason</a> on May 12, 2015.</h5>
                            <div>
                                <p>Bacon ipsum dolor sit amet nulla ham qui sint exercitation eiusmod commodo, chuck duis velit. Aute in reprehenderit, dolore aliqua non est magna in labore pig pork biltong in labore pig pork biltong.</p>
                            </div>
                            <a href="#" class="pull-left">Reply &raquo;</a>
                        </div>
                    </div>
                    <!-- Comment - End -->


					</div>
					<!-- Comments Section - End -->

					<div class="col-lg-8 col-md-8 col-sm-10 col-xs-10 comment-form inviewport animated delay1" data-effect="fadeIn">
						<h4>Post Your Comment</h4>
						
<!-- Comment Form - Start -->
<form action='http://jaybabani.com/caliber-html/send_email.php' method='post'><input type='text' placeholder='Name' class='col-xs-12 transition' id='comment_name' ><input type='text' placeholder='Email' class='col-xs-12 transition' id='comment_email' ><textarea class='col-xs-12 transition' placeholder='Message' id='comment_message' ></textarea><button type='button' class='btn btn-block btn-primary enabled transition' id='comment_send'>Send Message</button></form>
<!-- Contact Form - End -->
					</div>

				</div>


       </div>


	</div>
		<!-- Angled Section - Start -->
		<div class="angled_up_inside white">
			<div class="slope upleft"></div>
			<div class="slope upright"></div>
		</div>
		<!-- Angled Section - End -->
		
	</section>
<!-- Section End - Blog Single Page -->