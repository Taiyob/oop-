<?php
    $a = array(1,2,3,4,5);
    foreach($a as $value){
        echo $value . " ";
    }
?>
