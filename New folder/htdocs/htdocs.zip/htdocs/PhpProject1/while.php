<?php
    $i = $_GET["init"];
    $N = $_GET["range"];
    while($i <= $N){
        echo $i . "<br>";
        $i++;
    }
?>

