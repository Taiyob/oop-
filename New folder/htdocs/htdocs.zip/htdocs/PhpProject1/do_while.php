<?php
     $i = $_GET["init"];
    $N = $_GET["range"];
    do{
        echo $i . "<br>";
        $i++;
    }while($i <= $N);
?>
