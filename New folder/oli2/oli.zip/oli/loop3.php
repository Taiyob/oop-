<?php
$b=1;
$i=1;
while($i<=10){

	echo $i,"<br>";

$i=$i+2;
}

?>