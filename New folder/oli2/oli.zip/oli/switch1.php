<?php

$number=50;
switch($number){
	
	case 1:
	echo "you are selected,one";
	break;
	case 2:
	echo "you are selected,two";
	break;
	case 3:
	echo "you are selected,three";
	break;
	case 4:
	echo "you are selected,four";
	break;
	case 5:
	echo "you are selected,five";
	break;
	default:
	echo "not selected";
	break;
}


?>