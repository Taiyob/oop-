<?php
$b=1;

for ($i=1; $i <=1; $i++) { 
	# code...
	$b=$b*$i;
}
echo "$b";

?>