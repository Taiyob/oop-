<?php
$b=1;
$i=1;
while($i<=5){

	$b=$b*$i;

$i++;
}
echo "$b";
?>