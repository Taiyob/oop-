<?php

$i=11;
do{

	echo $i,"<br>";
	$i++;

}
while($i<10);

?>