<?php

for ($i=1; $i <=20 ; $i=$i+2 ){ 
	# code...
	
	echo $i,"<br>";

}



?>